"use strict";



{
	const scriptsInEvents = {

		async Es_common_Event310_Act1(runtime, localVars)
		{
			end(runtime);
		}

	};
	
	self.C3.ScriptsInEvents = scriptsInEvents;
}
